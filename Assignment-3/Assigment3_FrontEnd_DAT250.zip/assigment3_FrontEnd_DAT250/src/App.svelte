<script>
    import { onMount } from "svelte";

    // Datos generales
    let polls = [];
    let selectedPollId = '';
    let selectedPollOptions = [];
    let responseMessageCreatePoll = '';
    let responseMessageVote = '';

    // Datos para la creación de encuesta
    let pollQuestion = '';
    let validUntil = '';
    let options = [''];
    let username = '';
    let email = '';

    // Datos para la votación
    let voteUsername = '';
    let voteEmail = '';

    // Función para obtener todas las encuestas
    function fetchPolls() {
        fetch('http://localhost:8080/polls')
            .then(response => response.json())
            .then(data => {
                polls = Object.values(data);
            })
            .catch(error => console.error('Error fetching polls:', error));
    }

    // Cargar encuestas al montar el componente
    onMount(() => {
        fetchPolls();
    });

    // Crear una nueva encuesta
    function createPoll() {
        if (!pollQuestion || !username || !email) {
            responseMessageCreatePoll = 'All fields are required to create a poll!';
            return;
        }

        fetch('http://localhost:8080/polls', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                question: pollQuestion,
                publishedAt: new Date().toISOString(),
                validUntil: validUntil ? new Date(validUntil).toISOString() : null,
                user: { username: username, email: email }
            }),
        })
            .then(response => response.json())
            .then(poll => {
                options.forEach((optionCaption, index) => {
                    if (optionCaption !== '') {
                        fetch('http://localhost:8080/voteoptions', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                            },
                            body: JSON.stringify({
                                caption: optionCaption,
                                presentationOrder: index,
                                poll: { id: poll.id }
                            }),
                        })
                            .then(response => response.json())
                            .then(data => {
                                console.log('Option saved:', data);
                            })
                            .catch(error => {
                                console.error('Error saving option:', error);
                            });
                    }
                });

                responseMessageCreatePoll = 'Poll and options created successfully!';
                fetchPolls();  // Actualizar lista de encuestas
            })
            .catch(error => {
                responseMessageCreatePoll = 'Error creating poll.';
                console.error('Error:', error);
            });
    }

    // Obtener las opciones de la encuesta seleccionada
    function fetchPollOptions() {
        if (selectedPollId) {
            fetch(`http://localhost:8080/voteoptions/poll/${selectedPollId}`)
                .then(response => response.json())
                .then(data => {
                    console.log('Fetched poll options:', data); // Depuración
                    selectedPollOptions = Array.isArray(data) ? data : [];
                })
                .catch(error => {
                    console.error('Error fetching poll options:', error);
                });
        } else {
            selectedPollOptions = [];
        }
    }

    // Votar en una opción
    function vote(optionId) {
        const effectiveUsername = username || voteUsername;
        const effectiveEmail = email || voteEmail;

        if (!effectiveUsername || !effectiveEmail) {
            responseMessageVote = 'Username and email are required to vote.';
            return;
        }

        fetch('http://localhost:8080/votes', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                publishedAt: new Date().toISOString(),
                user: { username: effectiveUsername, email: effectiveEmail },
                voteOption: { id: optionId }
            }),
        })
            .then(response => response.json())
            .then(data => {
                responseMessageVote = 'Vote submitted successfully!';
                console.log('Vote submitted:', data);
            })
            .catch(error => {
                responseMessageVote = 'Error submitting vote.';
                console.error('Error:', error);
            });
    }

    // Añadir nuevas opciones en la creación de encuesta
    function addOption() {
        options = [...options, ''];
    }

    function updateOption(index, event) {
        options[index] = event.target.value;
    }
</script>

<main>
    <div class="create-poll-container">
        <h2>Create a New Poll</h2>

        <label for="pollQuestion">Poll Question:</label>
        <input type="text" id="pollQuestion" bind:value={pollQuestion} placeholder="Enter poll question..." />

        <label for="username">Username:</label>
        <input type="text" id="username" bind:value={username} placeholder="Enter your username..." />

        <label for="email">Email:</label>
        <input type="email" id="email" bind:value={email} placeholder="Enter your email..." />

        <label for="validUntil">Poll Expiration Date:</label>
        <input type="datetime-local" id="validUntil" bind:value={validUntil} />

        <div class="options-section">
            <h3>Poll Options</h3>

            {#each options as option, index}
                <div class="option-input">
                    <input
                            type="text"
                            placeholder={`Option ${index + 1}`}
                            bind:value={options[index]}
                            on:input={(event) => updateOption(index, event)}
                    />
                </div>
            {/each}

            <button class="add-option-button" on:click={addOption}>Add Option</button>
        </div>

        <button class="create-poll-button" on:click={createPoll}>Create Poll</button>

        {#if responseMessageCreatePoll}
            <p class="response-message success">{responseMessageCreatePoll}</p>
        {/if}
    </div>

    <div class="vote-section">
        <h2>Vote in a Poll</h2>

        <label for="voteUsername">Username:</label>
        <input type="text" id="voteUsername" bind:value={voteUsername} placeholder="Enter your username..." />

        <label for="voteEmail">Email:</label>
        <input type="email" id="voteEmail" bind:value={voteEmail} placeholder="Enter your email..." />

        <label for="pollSelection">Select Poll:</label>
        <select bind:value={selectedPollId} on:change={fetchPollOptions}>
            <option value="" disabled>Select a poll</option>
            {#each polls as poll}
                <option value={poll.id}>{poll.question}</option>
            {/each}
        </select>

        <div class="options-list">
            {#each selectedPollOptions as option}
                <button class="vote-option" on:click={() => vote(option.id)}>{option.caption}</button>
            {/each}
        </div>

        {#if responseMessageVote}
            <p class="response-message success">{responseMessageVote}</p>
        {/if}
    </div>
</main>

<style>
    /* Se mantiene el CSS original */
    body {
        font-family: 'Arial', sans-serif;
        background-color: #f4f4f4;
        display: flex;
        flex-direction: column;
        align-items: center;
        margin: 0;
        padding: 20px;
    }

    .create-poll-container, .vote-section {
        background-color: #fff;
        border-radius: 10px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        padding: 30px;
        width: 100%;
        max-width: 500px;
        margin-bottom: 20px;
    }

    h2 {
        color: #333;
        font-size: 24px;
        margin-bottom: 20px;
    }

    label {
        display: block;
        font-size: 14px;
        color: #666;
        margin-bottom: 5px;
        text-align: left;
    }

    input[type="text"],
    input[type="email"],
    input[type="datetime-local"] {
        width: calc(100% - 20px);
        padding: 10px;
        margin-bottom: 15px;
        border: 1px solid #ddd;
        border-radius: 5px;
        font-size: 14px;
        outline: none;
    }

    .options-section {
        margin-bottom: 20px;
    }

    .option-input {
        margin-bottom: 10px;
    }

    .add-option-button,
    .create-poll-button,
    .vote-button {
        background-color: #007bff;
        color: #fff;
        border: none;
        padding: 10px 20px;
        cursor: pointer;
        border-radius: 5px;
        font-size: 16px;
        transition: background-color 0.3s ease;
    }

    .add-option-button:hover,
    .create-poll-button:hover,
    .vote-button:hover {
        background-color: #0069d9;
    }

    .response-message {
        color: red;
        margin-top: 10px;
    }

    .response-message.success {
        color: green;
    }

    .vote-section select {
        width: 100%;
        padding: 10px;
        margin-bottom: 15px;
        border: 1px solid #ddd;
        border-radius: 5px;
        font-size: 14px;
    }

    .vote-section .option {
        display: flex;
        justify-content: space-between;
        margin-bottom: 10px;
    }

    .vote-section .vote-button {
        background-color: #007bff;
        font-size: 14px;
    }

    .vote-section .vote-button:hover {
        background-color: #0069d9;
    }
</style>
